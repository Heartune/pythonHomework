"""
Dialog components package for the Library Management System client.
"""
