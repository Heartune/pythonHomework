"""
Server network package for the Library Management System.
"""
