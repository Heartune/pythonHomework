"""
Data analysis unit tests package for the Library Management System.
"""
