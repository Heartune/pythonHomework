"""
GUI unit tests package for the Library Management System.
"""
